# RevenuePilot AI — MVP prototype

A responsive, mobile-first invoice follow-up dashboard. It is designed to work in a phone browser and adapt to tablet/laptop screens from the same codebase.

## Included in this first prototype

- Revenue overview: outstanding, overdue, collected this month, and open invoice counts.
- Invoice list with search.
- Add invoice form.
- Overdue invoice prioritization.
- AI-assisted reminder draft template with copy-to-clipboard.
- Mark invoices as paid.
- Local browser persistence using `localStorage`.
- Responsive mobile and desktop layouts.
- Sample data so the dashboard is populated on first launch.

## Run it

This is a static prototype. Open `index.html` in a browser, or deploy the folder to a static host. No build step is required.

## Important prototype limitations

This version is not yet a production SaaS. It does **not** include real user accounts, cloud database synchronization, invoice PDF upload/OCR, AI API calls, email sending, multi-tenant isolation, or Lemon Squeezy checkout/webhook integration. Data is stored only in the current browser on the current device. Clearing browser data can remove it. Sample client emails use the reserved `.example` domain and are not real addresses.

Do not enter real customer confidential information into this prototype. Before accepting customers, we must add server-side authentication, a secure database, tenant-level authorization, audit logging, privacy controls, and verified payment webhooks.

## Suggested next build stages

1. Create a Next.js application and Supabase project.
2. Add authentication and organization workspaces with row-level security.
3. Move invoice data from local storage into PostgreSQL.
4. Add secure invoice import and validation.
5. Add an AI service for drafting reminders, with human approval required.
6. Add email provider integration and delivery tracking.
7. Integrate Lemon Squeezy hosted checkout and signed webhooks; verify subscription status server-side.
8. Test billing, cancellation, failed payments, data access boundaries, and mobile usability before launch.

## Files

- `index.html` — application structure
- `styles.css` — responsive interface
- `app.js` — prototype interactions and local storage
